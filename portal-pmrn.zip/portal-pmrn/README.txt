PORTAL DE SISTEMAS — PMRN

Projeto estático de front-end. Não utiliza PHP, banco de dados ou framework.

COMO EXECUTAR
1. Extraia a pasta do ZIP.
2. Mantenha index.html, styles.css, systems.js, app.js e a pasta assets juntos.
3. Abra index.html no navegador.

PUBLICAÇÃO
Copie todos os arquivos e a pasta assets para o diretório público do servidor web.

CADASTRO DOS SISTEMAS
Edite systems.js para alterar nomes, descrições ou endereços.
Cada sistema deve ter:
- nome
- descricao
- sigla
- link

IMAGEM
O brasão utilizado está em assets/brasao-pmrn.png.
