(() => {
  "use strict";

  const grid = document.getElementById("systems-grid");
  const emptyState = document.getElementById("empty-state");
  const systems = Array.isArray(window.PMRN_SYSTEMS) ? window.PMRN_SYSTEMS : [];

  const isSafeHttpUrl = (value) => {
    try {
      const url = new URL(value);
      return url.protocol === "https:" || url.protocol === "http:";
    } catch {
      return false;
    }
  };

  systems.forEach((system) => {
    if (!system || typeof system.nome !== "string" || !isSafeHttpUrl(system.link)) return;

    const card = document.createElement("article");
    card.className = "system-card";

    const mark = document.createElement("div");
    mark.className = "system-mark";
    mark.setAttribute("aria-hidden", "true");
    mark.textContent = system.sigla || system.nome.slice(0, 2).toUpperCase();

    const name = document.createElement("h2");
    name.className = "system-name";
    name.textContent = system.nome;

    const description = document.createElement("p");
    description.className = "system-description";
    description.textContent = system.descricao || "";

    const link = document.createElement("a");
    link.className = "system-link";
    link.href = system.link;
    link.target = "_blank";
    link.rel = "noopener noreferrer";
    link.append(document.createTextNode("Acessar sistema "));

    const arrow = document.createElement("span");
    arrow.setAttribute("aria-hidden", "true");
    arrow.textContent = "↗";
    link.append(arrow);

    card.append(mark, name, description, link);
    grid.append(card);
  });

  if (!grid.children.length) {
    emptyState.hidden = false;
  }
})();
