/* Cadastro dos sistemas exibidos no catálogo. */
window.PMRN_SYSTEMS = [
  {
    nome: "SISGP",
    descricao: "Sistema Integrado de Gestão Policial.",
    sigla: "SG",
    link: "https://www3.pm.rn.gov.br/sisgp/home"
  },
  {
    nome: "RotaWeb",
    descricao: "Acesso ao sistema RotaWeb.",
    sigla: "RW",
    link: "https://rota.pm.rn.gov.br/home"
  },
  {
    nome: "Consulta Fácil",
    descricao: "Consulta de informações e serviços.",
    sigla: "CF",
    link: "https://www.consultafacil.pm.rn.gov.br/web/login"
  }
];
